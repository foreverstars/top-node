module.exports = {
  dbHost: 'localhost',
  dbPort: '27017',
  dbName: 'myblog'
}